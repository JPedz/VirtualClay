//
//  VirtualClay.h
//  VirtualClay
//
//  Created by JG Pedlingham on 09/03/2015.
//  Copyright (c) 2015 JG Pedlingham. All rights reserved.
//

#ifndef VirtualClay_VirtualClay_h
#define VirtualClay_VirtualClay_h
#include <cmath>
#include "cameraWrapper.h"
#include "MenuUI.h"

class VirtualClay: public mudbox::Node {
    DECLARE_CLASS
    //Q_DECLARE_TR_FUNCTIONS(VirtualClay);
public:
    static void Initializer(void);
};



#endif
