#include "stdafx.h"
//#include "SmoothMoveVertices.h"
//
//SmoothMoveVertices::SmoothMoveVertices(void)
//{
//}
//
//int Operator(mb::Mesh pMesh, int vertexIndex, int faceIndex) {
//  return 1;
//}
//
//bool Tester(mb::Mesh pMesh, int vertexIndex, int faceIndex) {
//  return false;
//}
//
//SmoothMoveVertices::~SmoothMoveVertices(void)
//{
//}
