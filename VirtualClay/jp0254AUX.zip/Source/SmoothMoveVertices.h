#pragma once
//#include "stdafx.h"
//
//namespace mb = mudbox;
//class SmoothMoveVertices : public mb::VertexEnumerator {
//  DECLARE_CLASS
//  float strength;
//  float dist;
//public:
//  SmoothMoveVertices(void);  ~SmoothMoveVertices(void);
//  int Operator();
//  bool Tester();
//  void setStrength(float percentage);
//  void setDistance(float dist);
//};
//
